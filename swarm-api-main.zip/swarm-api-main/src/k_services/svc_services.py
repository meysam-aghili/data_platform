from typing import Any, Dict, List
from docker import client
from docker.models.services import Service
from docker.types.services import \
    SecretReference, \
    ConfigReference, \
    RestartPolicy, \
    ServiceMode
from k_services.models import \
    SwarmService, \
    SwarmServiceDto, \
    SwarmCronJob, \
    SwarmSecretReference, \
    SwarmConfigReference
from k_shared.models import NewSwarmObjectDto
from k_shared.helpers import \
    get_object_id, \
    envs_to_dict, \
    get_network_aliases


_client = client.from_env()

def _service_to_dto(service: Service) -> SwarmServiceDto:
    return SwarmServiceDto(
        id = service.id,
        name = service.name,
        created_at = service.attrs['CreatedAt'],
        updated_at = service.attrs['UpdatedAt'],
        labels = service.attrs['Spec']['Labels'],
        image = (
            service.attrs
                ['Spec']
                ['TaskTemplate']
                ['ContainerSpec']
                ['Image']
        ),
        command = (
            service.attrs
                ['Spec']
                ['TaskTemplate']
                ['ContainerSpec']
                .get('Command', [])
        ),
        args = (
            service.attrs
                ['Spec']
                ['TaskTemplate']
                ['ContainerSpec']
                .get('Args', [])
        ),
        environment = envs_to_dict(
            service.attrs
                ['Spec']
                ['TaskTemplate']
                ['ContainerSpec']
                .get('Env', [])
        ),
        secrets = [
            SwarmSecretReference(
                id = secret['SecretID'],
                name = secret['SecretName'],
                file_name = secret['File']['Name']
            )
            for secret in (
                service.attrs
                    ['Spec']
                    ['TaskTemplate']
                    ['ContainerSpec']
                    .get('Secrets', [])
            )
        ],
        configs = [
            SwarmConfigReference(
                id = config['ConfigID'],
                name = config['ConfigName'],
                path = config['File']['Name']
            )
            for config in (
                service.attrs
                ['Spec']
                ['TaskTemplate']
                ['ContainerSpec']
                .get('Configs', [])
            )
        ],
        networks = get_network_aliases(
            service.attrs
                ['Spec']
                ['TaskTemplate']
                .get('Networks', [])
            )
    )

def _ls_services(filters: Dict[str, Any] = None) -> List[Service]:
    return _client.services.list(filters = filters)

def get_services(filters: Dict[str, Any] = None) -> List[SwarmServiceDto]:
    services = _ls_services(filters)
    return [ _service_to_dto(service) for service in services ]

def create_service(dto: SwarmService) -> NewSwarmObjectDto:
    service = _client.services.create(
        name = dto.name,
        labels = dto.labels,
        image = dto.image,
        command = dto.command,
        args = dto.args,
        env = [ f'{key}={dto.environment[key]}' for key in dto.environment ],
        networks = dto.networks,
        restart_policy = RestartPolicy(condition = dto.restart_condition),
        secrets = [
            SecretReference(
                secret_id = secret.id,
                secret_name = secret.name,
                filename = secret.file_name)
            for secret in dto.secrets
        ],
        configs = [
            ConfigReference(
                config_id = config.id,
                config_name = config.name,
                filename = config.path
            )
            for config in dto.configs
        ],
        mode = ServiceMode('replicated', dto.replicas)
    )
    return get_object_id(service)

def create_cronjob(dto: SwarmCronJob) -> SwarmServiceDto:
    dto.labels.update({
        'swarm.cronjob.enable': str(dto.cron_enabled).lower(),
        'swarm.cronjob.schedule': dto.cron_schedule,
        'swarm.cronjob.skip-running': str(dto.cron_skip_if_running).lower()
    })
    dto.replicas = 0
    dto.restart_condition = 'none'
    return create_service(dto)

def remove_service(service_id: str) -> bool:
    service = _client.services.get(service_id)
    return service.remove()
