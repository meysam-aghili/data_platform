from docker import client
from docker.types import LogConfig
from docker.errors import ContainerError
from k_containers.models import Job, JobResult
from k_shared.helpers import parse_exception, parse_logs


_client = client.from_env()
_log_config = LogConfig(type = LogConfig.types.JSON, config = {
    'max-size': '50m',
})

def run_container_attached(container: Job) -> JobResult:
    envs = container.environment
    if isinstance(container.secrets, list):
        secrets = {
            secret: secret for secret in container.secrets
        }
    elif isinstance(container.secrets, dict):
        secrets = container.secrets
    for secret in secrets:
        with open(f'/run/secrets/{secret}', 'r', encoding = 'utf-8') as scrt:
            envs[secrets[secret]] = scrt.read()[:-1]
    try:
        logs = _client.containers.run(
            name = container.name,
            image = container.image,
            entrypoint = container.entrypoint,
            command = container.command,
            environment = envs,
            extra_hosts = container.extra_hosts,
            network_mode = 'host' if container.host_network else None,
            stderr = True,
            log_config = _log_config,
            auto_remove = container.remove
        )
        return parse_logs(logs)
    except ContainerError as exc:
        return parse_exception(exc.stderr)
    except:
        raise
