from typing import List
import logging
from fastapi import FastAPI, status
from fastapi.responses import JSONResponse
from k_containers.models import Job
from k_services.models import \
    SwarmService, \
    SwarmServiceDto, \
    SwarmCronJob
from k_configs.models import \
    SwarmConfig, \
    SwarmConfigDto
from k_secrets.models import \
    SwarmSecret, \
    SwarmSecretDto
from k_services.svc_services import \
    create_service, \
    create_cronjob, \
    get_services, \
    remove_service
from k_configs.svc_configs import \
    create_config, \
    get_configs, \
    remove_config
from k_secrets.svc_secrets import \
    create_secret, \
    get_secrets, \
    remove_secret
from k_containers.svc_containers import run_container_attached
from k_shared.helpers import parse_filters

app = FastAPI()
logger = logging.getLogger(__name__)


@app.get('/configs')
async def endpoint_get_configs(query: str = None) -> List[SwarmConfigDto]:
    filters = parse_filters(query)
    return get_configs(filters)

@app.get('/secrets')
async def endpoint_get_secrets(query: str = None) -> List[SwarmSecretDto]:
    filters = parse_filters(query)
    return get_secrets(filters)

@app.get('/services')
async def endpoint_get_services(query: str = None) -> List[SwarmServiceDto]:
    filters = parse_filters(query)
    return get_services(filters)

@app.post('/secrets', status_code = status.HTTP_201_CREATED)
async def endpoint_post_secret(dto: SwarmSecret) -> str:
    return create_secret(dto)

@app.post('/configs', status_code = status.HTTP_201_CREATED)
async def endpoint_post_config(dto: SwarmConfig) -> str:
    return create_config(dto)

@app.post('/services', status_code = status.HTTP_201_CREATED)
async def endpoint_post_service(dto: SwarmService) -> str:
    return create_service(dto)

@app.post('/cronjobs')
async def endpoint_post_cronjob(dto: SwarmCronJob):
    return create_cronjob(dto)

@app.delete('/secrets/{secret_id}')
async def endpoint_delete_secret(secret_id: str):
    return remove_secret(secret_id)

@app.delete('/configs/{config_id}')
async def endpoint_delete_config(config_id: str):
    return remove_config(config_id)

@app.delete('/services/{service_id}')
async def endpoint_delete_service(service_id: str):
    return remove_service(service_id)

@app.post('/containers')
async def endpoint_post_container(dto: Job) -> dict:
    output = run_container_attached(dto)
    return JSONResponse(
        output.model_dump(),
        status_code = output.status_code)
