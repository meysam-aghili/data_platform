from typing import Dict, List, Optional
from pydantic import BaseModel, computed_field
from k_shared.models import SwarmObject


class Job(SwarmObject):
    image: str
    name: Optional[str] = None
    labels: Dict[str, str] = {}
    entrypoint: Optional[str]
    command: Optional[str]
    environment: Optional[Dict[str, str]] = []
    secrets: Optional[Dict[str, str]] = []
    networks: Optional[List[str]] = None
    extra_hosts: Optional[Dict[str, str]] = {}
    detached: Optional[bool] = False
    host_network: Optional[bool] = None
    remove: Optional[bool] = True

class JobResult(BaseModel):
    status_code: int
    message: Optional[str]

    @computed_field
    @property
    def is_success(self) -> bool:
        return 200 <= self.status_code < 300
