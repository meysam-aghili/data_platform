# swarm-api

API for management of Swarm Clusters.
