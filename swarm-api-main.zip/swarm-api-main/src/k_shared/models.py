from typing import Dict, Optional
from pydantic import BaseModel


class SwarmObject(BaseModel):
    id: Optional[str]
    name: str
    labels: Optional[Dict[str, str]]

class SwarmObjectDto(BaseModel):
    id: str
    name: str
    created_at: str
    updated_at: str
    labels: Dict[str, str] = {}

class NewSwarmObjectDto(BaseModel):
    id: str
    name: str
