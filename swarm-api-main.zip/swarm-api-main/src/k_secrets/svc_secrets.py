from typing import Any, Dict, List
from docker import client
from docker.models.secrets import Secret
from k_secrets.models import \
    SwarmSecret, \
    SwarmSecretDto
from k_shared.helpers import get_object_id


_client = client.from_env()

def _ls_secrets(filters: Dict[str, Any] = None) -> List[Secret]:
    return _client.secrets.list(filters = filters)

def _secret_to_dto(secret: Secret) -> SwarmSecretDto:
    return SwarmSecretDto(
        id = secret.id,
        name = secret.name,
        created_at = secret.attrs['CreatedAt'],
        updated_at = secret.attrs['UpdatedAt'],
        labels = secret.attrs['Spec']['Labels']
    )

def get_secrets(filters: Dict[str, Any] = None) -> List[SwarmSecretDto]:
    secrets = _ls_secrets(filters)
    return [ _secret_to_dto(secret) for secret in secrets ]

def create_secret(dto: SwarmSecret) -> SwarmSecretDto:
    secret = _client.secrets.create(
        name = dto.name,
        data = dto.value.encode('utf-8'),
        labels = dto.labels
    )
    return get_object_id(secret)

def remove_secret(secret_id: str) -> bool:
    secret = _client.secrets.get(secret_id)
    return secret.remove()
