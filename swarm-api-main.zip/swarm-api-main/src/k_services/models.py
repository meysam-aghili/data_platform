from typing import Dict, List, Optional
from k_configs.models import SwarmConfigReference
from k_secrets.models import SwarmSecretReference
from k_shared.models import SwarmObject, SwarmObjectDto


class SwarmService(SwarmObject):
    image: str
    command: Optional[List[str]]
    args: Optional[List[str]]
    environment: Optional[Dict[str, str]] = []
    secrets: Optional[List[SwarmSecretReference]] = []
    configs: Optional[List[SwarmConfigReference]] = []
    networks: Optional[List[str]]
    replicas: Optional[int] = 1
    restart_condition: Optional[str] = 'any'

class SwarmServiceDto(SwarmObjectDto):
    image: str
    command: List[str] = []
    args: List[str] = []
    environment: Dict[str, str]
    secrets: Optional[List[SwarmSecretReference]]
    configs: Optional[List[SwarmConfigReference]]
    networks: Optional[List[str]]
    replicas: Optional[int] = 1
    restart_condition: Optional[str] = 'any'

class SwarmCronJob(SwarmService):
    cron_enabled: bool
    cron_schedule: str
    cron_skip_if_running: bool
