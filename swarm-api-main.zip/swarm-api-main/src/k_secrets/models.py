from pydantic import BaseModel
from k_shared.models import SwarmObject, SwarmObjectDto


class SwarmSecret(SwarmObject):
    value: str

class SwarmSecretDto(SwarmObjectDto):
    pass

class SwarmSecretReference(BaseModel):
    id: str
    name: str
    file_name: str
