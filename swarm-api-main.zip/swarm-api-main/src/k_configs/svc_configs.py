import base64
from typing import Any, Dict, List
from docker import client
from docker.models.configs import Config
from k_configs.models import \
    SwarmConfig, \
    SwarmConfigDto
from k_shared.helpers import get_object_id


_client = client.from_env()

def _ls_configs(filters: Dict[str, Any] = None) -> List[Config]:
    return _client.configs.list(filters = filters)

def _config_to_dto(config: Config) -> SwarmConfigDto:
    return SwarmConfigDto(
        id = config.id,
        name = config.name,
        created_at = config.attrs['CreatedAt'],
        updated_at = config.attrs['UpdatedAt'],
        labels = config.attrs['Spec']['Labels'],
        data = config.attrs['Spec']['Data']
    )

def get_configs(filters: Dict[str, Any] = None) -> List[SwarmConfigDto]:
    configs = _ls_configs(filters)
    return [ _config_to_dto(config) for config in configs ]

def create_config(dto: SwarmConfig) -> str:
    config = _client.configs.create(
        name = dto.name,
        data = dto.data.encode('utf-8'),
        labels = dto.labels
    )
    return get_object_id(config)

def remove_config(config_id: str) -> bool:
    config = _client.configs.get(config_id)
    return config.remove()

def get_config_data(config_id: str) -> str:
    config = _client.configs.get(config_id)
    return (
        base64.b64decode(config.attrs['Spec']['Data'])
        .decode('utf-8')
    )
