from pydantic import BaseModel
from k_shared.models import SwarmObject, SwarmObjectDto


class SwarmConfig(SwarmObject):
    data: str

class SwarmConfigDto(SwarmObjectDto):
    data: str

class SwarmConfigReference(BaseModel):
    id: str
    name: str
    path: str
