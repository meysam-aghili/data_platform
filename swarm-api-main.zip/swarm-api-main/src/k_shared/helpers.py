import json
from typing import Any, Dict, List, Tuple, Union
from k_containers.models import JobResult


def parse_logs(logs: bytes) -> JobResult:
    logs_str = logs.decode('ascii').strip()
    try:
        logs_dict = json.loads(logs_str)
        return JobResult(**logs_dict)
    except:
        return JobResult(status_code = 200, details = logs_str)

def parse_exception(stderr: bytes) -> JobResult:
    exception_msg = stderr.decode('ascii')
    exception_msg = exception_msg.split('\n')[-2:-1][0]
    exception_msg = exception_msg.replace('Exception: ', '')
    try:
        exception_dict = json.loads(exception_msg)
        return JobResult(**exception_dict)
    except:
        return JobResult(status_code = 500, details = exception_msg)

def parse_filters(query: str) -> Union[Dict[str, Any], None]:
    return json.loads(query) if query else None

def split_env(env_string: str) -> Tuple[str, str]:
    return env_string.split('=', 1)

def envs_to_dict(envs: List[str]) -> Dict[str, str]:
    env_dict = {}
    for env in envs:
        key, value = split_env(env)
        env_dict[key] = value
    return env_dict

def get_object_id(docker_obj: Any) -> str:
    return docker_obj.attrs['ID']

def get_network_aliases(networks: List[Dict[str, Any]]) -> List[str]:
    aliases = [
        network.get('Aliases', [])
        for network in networks
    ]
    aliases = [
        alias[0]
        if len(alias) > 0
        else None
        for alias in aliases
    ]
    aliases = [ alias for alias in aliases if alias is not None ]
    aliases = list(set(aliases))
    return aliases
